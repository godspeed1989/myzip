dll16\zlib16.dll   :    The 16 bits DLL of ZLib 1.14
dll16\zlib16.lib   :    The 16 bits import library for the DLL of ZLib 1.14
dll32\zlib.dll     :    The 32 bits DLL of ZLib 1.14
dll32\zlib.lib     :    The 32 bits import library for the DLL of ZLib 1.14
static32\zlibstat.lib : The 32 bits statis library of zLib 1.14 for Visual C++
dll32\zlib_bor.lib :    The 32 bits import library for the DLL of ZLib 1.14 for Borland C++

I also include a version of zconf.h which must replace the version from zlib114.zip
The zlib.h included is the same version than in zlib114.zip

I've also added unzip.h and zip.h (please visit http://www.winimage.com/zLibDll/unzip.html )
